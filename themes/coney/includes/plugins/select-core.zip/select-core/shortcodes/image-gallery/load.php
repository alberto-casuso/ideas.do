<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/image-gallery/image-gallery.php';