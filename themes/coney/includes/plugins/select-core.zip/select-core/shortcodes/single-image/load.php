<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/single-image/single-image.php';