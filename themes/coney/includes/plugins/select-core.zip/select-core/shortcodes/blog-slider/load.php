<?php

include_once QODE_CORE_ABS_PATH . '/shortcodes/blog-slider/blog-slider.php';