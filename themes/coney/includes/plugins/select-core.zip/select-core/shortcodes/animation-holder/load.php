<?php

require_once QODE_CORE_ABS_PATH.'/shortcodes/animation-holder/animation-holder.php';