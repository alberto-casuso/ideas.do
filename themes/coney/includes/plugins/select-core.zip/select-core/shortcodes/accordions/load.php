<?php
require_once QODE_CORE_ABS_PATH.'/shortcodes/accordions/accordion.php';
require_once QODE_CORE_ABS_PATH.'/shortcodes/accordions/accordion-tab.php';
