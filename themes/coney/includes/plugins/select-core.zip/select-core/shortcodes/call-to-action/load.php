<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/call-to-action/call-to-action.php';