<li class="qodef-bl-item clearfix">
	<div class="qodef-bli-inner">
        <?php coney_qodef_get_module_template_part('templates/parts/image', 'blog', '', $params); ?>
		
		<div class="qodef-bli-content">
            <?php coney_qodef_get_module_template_part('templates/parts/title', 'blog', '', $params); ?>
			<?php coney_qodef_get_module_template_part('templates/parts/post-info/date', 'blog', '', $params); ?>
		</div>
	</div>
</li>