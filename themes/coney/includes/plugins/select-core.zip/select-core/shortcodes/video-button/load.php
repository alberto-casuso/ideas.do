<?php

include_once QODE_CORE_ABS_PATH . '/shortcodes/video-button/video-button.php';
include_once QODE_CORE_ABS_PATH . '/shortcodes/video-button/video-button-functions.php';