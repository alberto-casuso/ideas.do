<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/clients-carousel/clients-carousel.php';
include_once QODE_CORE_ABS_PATH.'/shortcodes/clients-carousel/clients-carousel-item.php';