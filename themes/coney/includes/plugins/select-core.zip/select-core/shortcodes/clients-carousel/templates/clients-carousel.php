<div class="qodef-clients-carousel-holder <?php echo esc_attr($holder_classes); ?>" <?php echo coney_qodef_get_inline_attrs($carousel_data); ?>>
	<div class="qodef-cc-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>