<div class="qodef-parallax-holder <?php echo esc_attr($holder_class); ?>" <?php echo coney_qodef_get_inline_attrs($holder_data); ?> <?php echo coney_qodef_get_inline_style($holder_style); ?>>
	<div class="qodef-parallax-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>
