<?php

include_once QODE_CORE_ABS_PATH . '/shortcodes/blog-video-list/blog-video-list.php';