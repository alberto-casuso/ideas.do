<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/socialshare/social-share-functions.php';
include_once QODE_CORE_ABS_PATH.'/shortcodes/socialshare/social-share.php';