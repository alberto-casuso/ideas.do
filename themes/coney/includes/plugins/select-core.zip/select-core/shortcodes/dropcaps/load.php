<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/dropcaps/dropcaps.php';