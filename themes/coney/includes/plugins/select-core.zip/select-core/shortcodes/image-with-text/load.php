<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/image-with-text/image-with-text.php';