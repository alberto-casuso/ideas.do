<div <?php coney_qodef_class_attribute($holder_classes); ?>>
    <?php echo do_shortcode($content); ?>
</div>